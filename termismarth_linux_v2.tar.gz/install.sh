#!/bin/bash

echo "🧠 Configurando o TermiSmarth no seu Linux..."
PASTA_ATUAL=$(dirname $(readlink -f "$0"))

# Injeta o gancho no sistema apontando direto para o executável compilado do Linux!
if ! grep -q "command_not_found_handle" ~/.bashrc; then
    cat << EOF >> ~/.bashrc

# --- GANCHO INTELIGENTE TERMISMARTH LINUX ---
command_not_found_handle() {
    "$PASTA_ATUAL/termismarth_linux/termismarth_linux" "\$@"
    return 127
}
EOF
    echo "✅ TermiSmarth integrado ao terminal com sucesso!"
else
    echo "⚠️ O TermiSmarth já está configurado no sistema."
fi

echo "🚀 Pronto! Digite 'source ~/.bashrc' para ativar."

